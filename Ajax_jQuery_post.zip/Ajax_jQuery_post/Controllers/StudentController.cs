﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Ajax_jQuery_post.Models;
using Newtonsoft.Json;

namespace Ajax_jQuery_post.Controllers
{
    public class StudentController : Controller
    {
        // GET: Student
        public ActionResult Index()
        {
            return View();
        }
        public JsonResult GetStudent()
        {
            Student std = new Student()
            {
                Id = 1,
                StudentAddress = "trisha682email@gmail.com",
                StudentName = "Trisha Maitra"

            };
            var json = JsonConvert.SerializeObject(std);
            return Json(json, JsonRequestBehavior.AllowGet);
        }
        [HttpPost]
        public JsonResult AddStudent(Student student)
        {
            return Json("true", JsonRequestBehavior.AllowGet);

        }
    }
}